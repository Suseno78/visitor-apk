import { useState, useEffect, useCallback } from 'react';
import { Visitor, VisitorCategory } from '../types';
import { VisitorStorage } from '../storage/storage';

export function useVisitors() {
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [loading, setLoading] = useState(true);

  const loadVisitors = useCallback(async () => {
    setLoading(true);
    const data = await VisitorStorage.getAll();
    setVisitors(data.sort((a, b) => b.createdAt - a.createdAt));
    setLoading(false);
  }, []);

  useEffect(() => {
    loadVisitors();
  }, [loadVisitors]);

  const addVisitor = async (visitor: Visitor) => {
    await VisitorStorage.save(visitor);
    await loadVisitors();
  };

  const updateVisitor = async (visitor: Visitor) => {
    await VisitorStorage.update(visitor);
    await loadVisitors();
  };

  const deleteVisitor = async (id: string) => {
    await VisitorStorage.delete(id);
    await loadVisitors();
  };

  const clearAll = async () => {
    await VisitorStorage.clearAll();
    await loadVisitors();
  };

  const getStats = () => {
    const total = visitors.length;
    const vip = visitors.filter((v) => v.category === 'VIP').length;
    const reguler = visitors.filter((v) => v.category === 'Reguler').length;
    const family = visitors.filter((v) => v.category === 'Family').length;
    const partner = visitors.filter((v) => v.category === 'Partner').length;
    return { total, vip, reguler, family, partner };
  };

  const getRecent = (count = 5) => visitors.slice(0, count);

  const searchByName = (query: string) =>
    visitors.filter((v) =>
      v.name.toLowerCase().includes(query.toLowerCase())
    );

  const filterByCategory = (category: VisitorCategory | 'Semua') =>
    category === 'Semua' ? visitors : visitors.filter((v) => v.category === category);

  return {
    visitors,
    loading,
    loadVisitors,
    addVisitor,
    updateVisitor,
    deleteVisitor,
    clearAll,
    getStats,
    getRecent,
    searchByName,
    filterByCategory,
  };
}
