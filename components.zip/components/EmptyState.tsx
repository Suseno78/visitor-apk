import { View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { PrimaryButton } from './PrimaryButton';
import { Colors, Typography, Spacing, Radius } from '../constants/colors';

interface Props {
  onAddPress?: () => void;
}

export function EmptyState({ onAddPress }: Props) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: Spacing.xxl, paddingVertical: Spacing.xxl }}>
      <View
        style={{
          width: 88,
          height: 88,
          borderRadius: 24,
          backgroundColor: Colors.primarySurface,
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: Spacing.lg,
        }}
      >
        <Ionicons name="people-outline" size={40} color={Colors.primary} />
      </View>
      <Text style={[Typography.h3, { color: Colors.textPrimary, marginBottom: Spacing.sm, textAlign: 'center' }]}>
        Belum ada visitor
      </Text>
      <Text
        style={[
          Typography.body,
          { color: Colors.textSecondary, textAlign: 'center', marginBottom: Spacing.xl, lineHeight: 22, maxWidth: 260 },
        ]}
      >
        Mulai tambahkan visitor pertama Anda dan kelola dengan mudah
      </Text>
      {onAddPress && <PrimaryButton title="Tambah Visitor" icon="add" onPress={onAddPress} fullWidth={false} />}
    </View>
  );
}
