import { TouchableOpacity, View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Visitor } from '../types';
import { CategoryBadge } from './CategoryBadge';
import { Colors, Typography, Shadows, Radius, Spacing } from '../constants/colors';

interface Props {
  visitor: Visitor;
  onPress: () => void;
}

export function VisitorCard({ visitor, onPress }: Props) {
  const avatarBg = Colors.categoryBg[visitor.category] || Colors.categoryBg.Reguler;
  const avatarColor = Colors.category[visitor.category] || Colors.category.Reguler;

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={{
        backgroundColor: Colors.card,
        borderRadius: Radius.xl,
        padding: Spacing.md,
        marginBottom: Spacing.sm + 4,
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadows.card,
      }}
    >
      {/* Avatar */}
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: Radius.md,
          backgroundColor: avatarBg,
          alignItems: 'center',
          justifyContent: 'center',
          marginRight: Spacing.md,
        }}
      >
        <Ionicons name="person" size={20} color={avatarColor} />
      </View>

      {/* Info */}
      <View style={{ flex: 1, marginRight: Spacing.sm }}>
        <Text
          style={[Typography.bodySemibold, { color: Colors.textPrimary, marginBottom: 2 }]}
          numberOfLines={1}
        >
          {visitor.name}
        </Text>
        <Text
          style={[Typography.bodySmall, { color: Colors.textTertiary, marginBottom: 6 }]}
          numberOfLines={1}
        >
          {visitor.occupation || 'Umum'}
        </Text>
        <CategoryBadge category={visitor.category} />
      </View>

      {/* Chevron */}
      <View
        style={{
          width: 28,
          height: 28,
          borderRadius: Radius.sm,
          backgroundColor: Colors.primarySurface,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name="chevron-forward" size={14} color={Colors.primary} />
      </View>
    </TouchableOpacity>
  );
}
