import { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, Modal, TouchableOpacity, FlatList, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Visitor } from '../types';
import { VisitorCard } from './VisitorCard';
import { Colors, Typography, Spacing, Radius, Shadows } from '../constants/colors';
import { useResponsive } from '../constants/layout';

interface Props {
  visible: boolean;
  onClose: () => void;
  visitors: Visitor[];
  onVisitorPress: (id: string) => void;
}

export function SearchModal({ visible, onClose, visitors, onVisitorPress }: Props) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<TextInput>(null);
  const slideAnim = useRef(new Animated.Value(-40)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const { statusBarPadding, horizontalPadding, contentMaxWidth, isTablet } = useResponsive();

  const filtered = query.trim()
    ? visitors.filter(
        (v) =>
          v.name.toLowerCase().includes(query.toLowerCase()) ||
          (v.occupation || '').toLowerCase().includes(query.toLowerCase()) ||
          v.category.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  useEffect(() => {
    if (visible) {
      setQuery('');
      Animated.parallel([
        Animated.spring(slideAnim, { toValue: 0, friction: 8, tension: 65, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start(() => {
        setTimeout(() => inputRef.current?.focus(), 100);
      });
    } else {
      slideAnim.setValue(-40);
      fadeAnim.setValue(0);
    }
  }, [visible]);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(slideAnim, { toValue: -40, duration: 150, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 0, duration: 150, useNativeDriver: true }),
    ]).start(() => onClose());
  };

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <Animated.View
        style={{
          flex: 1,
          backgroundColor: Colors.background,
          opacity: fadeAnim,
        }}
      >
        {/* Header */}
        <Animated.View
          style={{
            paddingTop: statusBarPadding + Spacing.sm,
            paddingHorizontal: horizontalPadding,
            paddingBottom: Spacing.md,
            backgroundColor: Colors.card,
            ...Shadows.md,
            transform: [{ translateY: slideAnim }],
            alignItems: isTablet ? 'center' : undefined,
          }}
        >
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: Spacing.md,
            maxWidth: contentMaxWidth,
            width: '100%',
          }}>
            <TouchableOpacity
              onPress={handleClose}
              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                backgroundColor: Colors.background,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Ionicons name="arrow-back" size={20} color={Colors.textPrimary} />
            </TouchableOpacity>
            <View
              style={{
                flex: 1,
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: Colors.background,
                borderRadius: Radius.md,
                paddingHorizontal: Spacing.md,
                height: 44,
                borderWidth: 1,
                borderColor: Colors.border,
              }}
            >
              <Ionicons name="search" size={18} color={Colors.textSecondary} style={{ marginRight: Spacing.sm }} />
              <TextInput
                ref={inputRef}
                value={query}
                onChangeText={setQuery}
                placeholder="Cari nama, kategori, atau pekerjaan..."
                placeholderTextColor={Colors.textTertiary}
                style={[Typography.body, { flex: 1, color: Colors.textPrimary }]}
                returnKeyType="search"
                autoCorrect={false}
              />
              {query.length > 0 && (
                <TouchableOpacity onPress={() => setQuery('')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <Ionicons name="close-circle" size={18} color={Colors.textSecondary} />
                </TouchableOpacity>
              )}
            </View>
          </View>
        </Animated.View>

        {/* Results */}
        <View style={{ flex: 1, alignItems: isTablet ? 'center' : undefined }}>
          <View style={{ maxWidth: contentMaxWidth, width: '100%', flex: 1 }}>
            {query.trim().length === 0 ? (
              <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: Spacing.xxl }}>
                <View
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 20,
                    backgroundColor: Colors.primarySurface,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: Spacing.lg,
                  }}
                >
                  <Ionicons name="search-outline" size={34} color={Colors.primary} />
                </View>
                <Text style={[Typography.h4, { color: Colors.textPrimary, marginBottom: Spacing.sm }]}>
                  Cari Visitor
                </Text>
                <Text style={[Typography.body, { color: Colors.textSecondary, textAlign: 'center' }]}>
                  Ketik nama, kategori, atau pekerjaan untuk mencari
                </Text>
              </View>
            ) : filtered.length === 0 ? (
              <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: Spacing.xxl }}>
                <Ionicons name="search-outline" size={52} color={Colors.textTertiary} />
                <Text style={[Typography.h4, { color: Colors.textPrimary, marginTop: Spacing.md, marginBottom: Spacing.sm }]}>
                  Tidak ditemukan
                </Text>
                <Text style={[Typography.body, { color: Colors.textSecondary, textAlign: 'center' }]}>
                  Tidak ada hasil untuk "{query}"
                </Text>
              </View>
            ) : (
              <FlatList
                data={filtered}
                keyExtractor={(item) => item.id}
                contentContainerStyle={{ padding: horizontalPadding, paddingTop: Spacing.md }}
                renderItem={({ item }) => (
                  <VisitorCard
                    visitor={item}
                    onPress={() => {
                      handleClose();
                      setTimeout(() => onVisitorPress(item.id), 200);
                    }}
                  />
                )}
                ListHeaderComponent={
                  <Text style={[Typography.caption, { color: Colors.textSecondary, marginBottom: Spacing.sm }]}>
                    {filtered.length} hasil ditemukan
                  </Text>
                }
              />
            )}
          </View>
        </View>
      </Animated.View>
    </Modal>
  );
}
