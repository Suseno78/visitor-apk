import { View, Text, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing } from '../constants/colors';
import { useResponsive } from '../constants/layout';

interface Props {
  name: string;
}

export function DashboardHeader({ name }: Props) {
  const { statusBarPadding, horizontalPadding } = useResponsive();

  return (
    <View
      style={{
        backgroundColor: Colors.primary,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
        paddingTop: statusBarPadding + Spacing.sm,
        paddingBottom: 40,
        paddingHorizontal: horizontalPadding,
      }}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View style={{ flex: 1 }}>
          <Image
            source={require('../assets/v-removebg-preview.png')}
            style={{ width: 32, height: 32, resizeMode: 'contain', marginBottom: Spacing.md, tintColor: Colors.white }}
          />
          <Text
            style={[Typography.h1, { color: Colors.white, marginBottom: 4 }]}
          >
            Hi, {name}
          </Text>
          <Text
            style={[Typography.bodySmall, { color: 'rgba(255,255,255,0.6)' }]}
          >
            Kelola kunjungan dengan mudah
          </Text>
        </View>

        {/* Notification bell */}
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            backgroundColor: 'rgba(255,255,255,0.1)',
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: 4,
          }}
        >
          <Ionicons name="notifications-outline" size={20} color={Colors.white} />
        </View>
      </View>
    </View>
  );
}
