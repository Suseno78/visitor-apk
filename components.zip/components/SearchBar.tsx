import { View, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Radius, Spacing, Shadows } from '../constants/colors';

interface Props {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
}

export function SearchBar({
  value,
  onChangeText,
  placeholder = 'Cari visitor...',
}: Props) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.card,
        borderRadius: Radius.lg,
        paddingHorizontal: Spacing.md,
        paddingVertical: 12,
        ...Shadows.md,
      }}
    >
      <Ionicons
        name="search"
        size={20}
        color={Colors.textSecondary}
        style={{ marginRight: 10 }}
      />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={Colors.textTertiary}
        style={[Typography.body, { flex: 1, color: Colors.textPrimary }]}
      />
    </View>
  );
}
