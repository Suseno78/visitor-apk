import { View, Image } from 'react-native';
import { Colors } from '../constants/colors';

interface Props {
  size?: number;
  showText?: boolean;
}

export function LogoHeader({ size = 32 }: Props) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Image
        source={require('../assets/v.png')}
        style={{ width: size, height: size, resizeMode: 'contain' }}
      />
    </View>
  );
}
