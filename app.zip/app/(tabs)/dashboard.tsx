import { useState, useRef, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useVisitors } from '../../hooks/useVisitors';
import { DashboardHeader } from '../../components/DashboardHeader';
import { StatsCard } from '../../components/StatsCard';
import { CategoryIcon } from '../../components/CategoryIcon';
import { VisitorCard } from '../../components/VisitorCard';
import { SearchModal } from '../../components/SearchModal';
import { EmptyState } from '../../components/EmptyState';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../constants/colors';
import { useResponsive, TAB_BAR_TOTAL_HEIGHT } from '../../constants/layout';

export default function DashboardScreen() {
  const router = useRouter();
  const { visitors, getStats, getRecent } = useVisitors();
  const stats = getStats();
  const recent = getRecent(5);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchModal, setShowSearchModal] = useState(false);
  const { horizontalPadding, isTablet, contentMaxWidth } = useResponsive();
  const searchInputRef = useRef<TextInput>(null);

  const filteredRecent = searchQuery.trim()
    ? recent.filter(
        (v) =>
          v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (v.occupation || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : recent;

  const showFullSearch = useCallback(() => {
    setSearchQuery('');
    setShowSearchModal(true);
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + 24,
          ...(isTablet ? { alignItems: 'center' } : {}),
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ width: '100%' }}>
          <DashboardHeader name="Wantiono" />
        </View>

        <View style={{ width: '100%', maxWidth: isTablet ? contentMaxWidth : undefined, paddingHorizontal: horizontalPadding }}>
          {/* Inline Search Bar */}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: Colors.card,
              borderRadius: Radius.lg,
              paddingHorizontal: Spacing.md,
              height: 48,
              marginTop: -24,
              borderWidth: 1,
              borderColor: Colors.borderLight,
              ...Shadows.md,
            }}
          >
            <Ionicons name="search-outline" size={18} color={Colors.textTertiary} style={{ marginRight: 10 }} />
            <TextInput
              ref={searchInputRef}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Cari visitor..."
              placeholderTextColor={Colors.textTertiary}
              style={[Typography.body, { flex: 1, color: Colors.textPrimary }]}
              returnKeyType="search"
              autoCorrect={false}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Ionicons name="close-circle" size={18} color={Colors.textTertiary} />
              </TouchableOpacity>
            )}
            <TouchableOpacity
              onPress={showFullSearch}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{ marginLeft: Spacing.xs, width: 30, height: 30, borderRadius: Radius.sm, backgroundColor: Colors.primarySurface, alignItems: 'center', justifyContent: 'center' }}
            >
              <Ionicons name="expand-outline" size={14} color={Colors.primary} />
            </TouchableOpacity>
          </View>

          {/* Stats Cards */}
          <View style={{ flexDirection: 'row', gap: Spacing.sm + 4, marginTop: Spacing.xl }}>
            <StatsCard
              icon="people-outline"
              iconColor={Colors.primary}
              iconBg={Colors.primarySurface}
              label="Total Visitor"
              value={stats.total}
              subtitle=""
              trend="+10%"
              trendUp
              accentColor={Colors.primaryLight}
            />
            <StatsCard
              icon="diamond-outline"
              iconColor={Colors.category.VIP}
              iconBg={Colors.categoryBg.VIP}
              label="VIP Visitor"
              value={stats.vip}
              subtitle=""
              trend="+5%"
              trendUp
              accentColor={Colors.categoryAccent.VIP}
            />
          </View>

          {/* Kategori Visitor */}
          <View style={{ marginTop: Spacing.xl }}>
            <Text style={[Typography.h4, { color: Colors.textPrimary, marginBottom: Spacing.md }]}>
              Kategori Visitor
            </Text>
            <View
              style={{
                flexDirection: 'row',
                backgroundColor: Colors.card,
                borderRadius: Radius.xl,
                padding: Spacing.lg,
                borderWidth: 1,
                borderColor: Colors.borderLight,
                ...Shadows.card,
              }}
            >
              <CategoryIcon category="VIP" count={stats.vip} onPress={() => router.push('/(tabs)/visitors')} />
              <CategoryIcon category="Reguler" count={stats.reguler} onPress={() => router.push('/(tabs)/visitors')} />
              <CategoryIcon category="Family" count={stats.family} onPress={() => router.push('/(tabs)/visitors')} />
            </View>
          </View>

          {/* Visitor Terbaru */}
          <View style={{ marginTop: Spacing.xl, marginBottom: Spacing.lg }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md }}>
              <Text style={[Typography.h4, { color: Colors.textPrimary }]}>
                Visitor Terbaru
              </Text>
              {visitors.length > 0 && (
                <TouchableOpacity onPress={() => router.push('/(tabs)/visitors')} activeOpacity={0.7}>
                  <Text style={[Typography.bodySmall, { color: Colors.primary, fontWeight: '600' }]}>Lihat Semua</Text>
                </TouchableOpacity>
              )}
            </View>

            {visitors.length === 0 ? (
              <EmptyState onAddPress={() => router.push('/visitor/add')} />
            ) : searchQuery.trim() && filteredRecent.length === 0 ? (
              <View style={{ paddingVertical: Spacing.xxl, alignItems: 'center' }}>
                <View style={{ width: 56, height: 56, borderRadius: 16, backgroundColor: Colors.primarySurface, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md }}>
                  <Ionicons name="search-outline" size={24} color={Colors.primary} />
                </View>
                <Text style={[Typography.body, { color: Colors.textSecondary, textAlign: 'center' }]}>
                  Tidak ditemukan untuk "{searchQuery}"
                </Text>
              </View>
            ) : (
              filteredRecent.map((visitor) => (
                <VisitorCard
                  key={visitor.id}
                  visitor={visitor}
                  onPress={() => router.push(`/visitor/${visitor.id}`)}
                />
              ))
            )}
          </View>
        </View>
      </ScrollView>

      <SearchModal
        visible={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        visitors={visitors}
        onVisitorPress={(id) => router.push(`/visitor/${id}`)}
      />
    </View>
  );
}
