import { useState, useRef, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, FlatList, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useVisitors } from '../../hooks/useVisitors';
import { VisitorCard } from '../../components/VisitorCard';
import { VisitorStatsRow } from '../../components/VisitorStatsRow';
import { SearchModal } from '../../components/SearchModal';
import { FilterSheet, FilterState } from '../../components/FilterSheet';
import { FloatingActionButton } from '../../components/FloatingActionButton';
import { EmptyState } from '../../components/EmptyState';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../constants/colors';
import { useResponsive, TAB_BAR_TOTAL_HEIGHT } from '../../constants/layout';
import { VisitorCategory } from '../../types';

type TabKey = 'Semua' | VisitorCategory;
const tabs: TabKey[] = ['Semua', 'VIP', 'Reguler', 'Family'];

const tabColors: Record<TabKey, string> = {
  Semua: Colors.primary,
  VIP: Colors.category.VIP,
  Reguler: Colors.category.Reguler,
  Family: Colors.category.Family,
  Partner: Colors.category.Partner,
};

export default function VisitorsScreen() {
  const router = useRouter();
  const { visitors, filterByCategory, getStats } = useVisitors();
  const [selectedTab, setSelectedTab] = useState<TabKey>('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  const [filter, setFilter] = useState<FilterState>({ category: 'Semua', time: 'all' });
  const { statusBarPadding, horizontalPadding, isTablet, contentMaxWidth } = useResponsive();
  const stats = getStats();
  const searchInputRef = useRef<TextInput>(null);
  const scrollRef = useRef<ScrollView>(null);

  // Apply filters
  let filtered = filterByCategory(selectedTab);
  if (filter.category !== 'Semua') {
    filtered = filtered.filter((v) => v.category === filter.category);
  }

  // Apply inline search
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(
      (v) =>
        v.name.toLowerCase().includes(q) ||
        (v.occupation || '').toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q)
    );
  }

  const toggleSearch = useCallback(() => {
    setShowSearchInput((prev) => {
      if (!prev) {
        setTimeout(() => searchInputRef.current?.focus(), 100);
      } else {
        setSearchQuery('');
      }
      return !prev;
    });
  }, []);

  const statsItems = [
    {
      icon: 'people-outline' as const,
      iconColor: Colors.primary,
      iconBg: Colors.primarySurface,
      label: 'Semua',
      value: stats.total,
      subtitle: 'Visitor',
    },
    {
      icon: 'sparkles-outline' as const,
      iconColor: Colors.statsGreen,
      iconBg: Colors.successLight,
      label: 'Baru',
      value: stats.total,
      subtitle: 'Hari ini',
    },
    {
      icon: 'calendar-outline' as const,
      iconColor: Colors.statsAmber,
      iconBg: Colors.warningLight,
      label: 'Kunjungan',
      value: stats.total * 2,
      subtitle: 'Total',
    },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Header */}
      <View
        style={{
          backgroundColor: Colors.primary,
          paddingTop: statusBarPadding,
          paddingBottom: Spacing.md + 4,
          paddingHorizontal: horizontalPadding,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <Text style={[Typography.h2, { color: Colors.white }]}>
          Visitor
        </Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <TouchableOpacity
            onPress={() => setShowSearchModal(true)}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            style={{
              width: 36,
              height: 36,
              borderRadius: Radius.sm + 2,
              backgroundColor: 'rgba(255,255,255,0.1)',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="search-outline" size={20} color={Colors.white} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Inline Search Bar */}
      {showSearchInput && (
        <View
          style={{
            backgroundColor: Colors.white,
            paddingHorizontal: horizontalPadding,
            paddingVertical: Spacing.sm,
            borderBottomWidth: 1,
            borderBottomColor: Colors.border,
          }}
        >
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: Colors.background,
              borderRadius: Radius.md,
              paddingHorizontal: Spacing.md,
              height: 42,
            }}
          >
            <Ionicons name="search" size={18} color={Colors.textSecondary} style={{ marginRight: Spacing.sm }} />
            <TextInput
              ref={searchInputRef}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Cari visitor..."
              placeholderTextColor={Colors.textSecondary}
              style={[Typography.body, { flex: 1, color: Colors.textPrimary }]}
              returnKeyType="search"
              autoCorrect={false}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Ionicons name="close-circle" size={18} color={Colors.textSecondary} />
              </TouchableOpacity>
            )}
            <TouchableOpacity
              onPress={toggleSearch}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{ marginLeft: Spacing.sm }}
            >
              <Ionicons name="close" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Category Tabs */}
      <View style={{ backgroundColor: Colors.white, ...Shadows.sm }}>
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{
            paddingHorizontal: horizontalPadding,
            paddingVertical: Spacing.md,
            gap: Spacing.sm,
          }}
        >
          {tabs.map((tab) => {
            const isActive = selectedTab === tab;
            const color = tabColors[tab];
            return (
              <TouchableOpacity
                key={tab}
                onPress={() => setSelectedTab(tab)}
                activeOpacity={0.7}
                style={{
                  paddingHorizontal: Spacing.md + 4,
                  paddingVertical: Spacing.sm,
                  borderRadius: Radius.pill,
                  backgroundColor: isActive ? color : Colors.background,
                }}
              >
                <Text
                  style={[
                    Typography.bodySmall,
                    {
                      fontWeight: isActive ? '600' : '500',
                      color: isActive ? Colors.white : Colors.textSecondary,
                    },
                  ]}
                >
                  {tab}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {/* Content */}
      <View style={{ flex: 1, alignItems: isTablet ? 'center' : undefined }}>
        <View style={{ flex: 1, maxWidth: isTablet ? contentMaxWidth : undefined, width: '100%' }}>
          {/* Stats Row */}
          <View style={{ paddingHorizontal: horizontalPadding, marginTop: Spacing.md }}>
            <VisitorStatsRow stats={statsItems} />
          </View>

          {/* Daftar Visitor Header */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: horizontalPadding,
              marginTop: Spacing.md,
              marginBottom: Spacing.sm,
            }}
          >
            <Text style={[Typography.h4, { color: Colors.textPrimary }]}>
              Daftar Visitor
            </Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <TouchableOpacity
                onPress={toggleSearch}
                activeOpacity={0.7}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: Colors.primarySurface,
                  paddingHorizontal: Spacing.sm + 2,
                  paddingVertical: 5,
                  borderRadius: Radius.pill,
                }}
              >
                <Ionicons name="search-outline" size={14} color={Colors.primary} />
                <Text style={{ fontSize: 12, color: Colors.primary, fontWeight: '600', marginLeft: 4 }}>
                  Cari
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => setShowFilter(true)}
                activeOpacity={0.7}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: Colors.primarySurface,
                  paddingHorizontal: Spacing.sm + 2,
                  paddingVertical: 5,
                  borderRadius: Radius.pill,
                }}
              >
                <Ionicons name="funnel-outline" size={14} color={Colors.primary} />
                <Text style={{ fontSize: 12, color: Colors.primary, fontWeight: '600', marginLeft: 4 }}>
                  Filter
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Visitor List */}
          {filtered.length === 0 ? (
            <View style={{ flex: 1, paddingTop: 20 }}>
              <EmptyState />
            </View>
          ) : (
            <FlatList
              data={filtered}
              keyExtractor={(item) => item.id}
              contentContainerStyle={{
                paddingHorizontal: horizontalPadding,
                paddingBottom: TAB_BAR_TOTAL_HEIGHT + 80,
              }}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => (
                <VisitorCard
                  visitor={item}
                  onPress={() => router.push(`/visitor/${item.id}`)}
                />
              )}
            />
          )}
        </View>
      </View>

      {/* Floating Action Button */}
      <FloatingActionButton onPress={() => router.push('/visitor/add')} />

      {/* Search Modal (advanced search) */}
      <SearchModal
        visible={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        visitors={visitors}
        onVisitorPress={(id) => router.push(`/visitor/${id}`)}
      />

      {/* Filter Sheet */}
      <FilterSheet
        visible={showFilter}
        onClose={() => setShowFilter(false)}
        currentFilter={filter}
        onApply={(f) => {
          setFilter(f);
          if (f.category !== 'Semua') setSelectedTab(f.category);
          setShowFilter(false);
        }}
      />
    </View>
  );
}
