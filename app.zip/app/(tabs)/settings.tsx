import { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVisitors } from '../../hooks/useVisitors';
import { ConfirmationModal } from '../../components/ConfirmationModal';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../constants/colors';
import { useResponsive, TAB_BAR_TOTAL_HEIGHT } from '../../constants/layout';

function SettingsRow({
  icon,
  label,
  value,
  onPress,
  danger,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value?: string;
  onPress?: () => void;
  danger?: boolean;
}) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper
      {...(onPress ? { onPress, activeOpacity: 0.7 } : {})}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 14,
        minHeight: 50,
      }}
    >
      <View
        style={{
          width: 34,
          height: 34,
          borderRadius: Radius.sm + 2,
          backgroundColor: danger ? Colors.dangerLight : Colors.primarySurface,
          alignItems: 'center',
          justifyContent: 'center',
          marginRight: Spacing.md,
        }}
      >
        <Ionicons name={icon} size={17} color={danger ? Colors.danger : Colors.primary} />
      </View>
      <Text
        style={[Typography.body, { flex: 1, color: danger ? Colors.danger : Colors.textPrimary, fontWeight: '500' }]}
      >
        {label}
      </Text>
      {value && (
        <Text style={[Typography.bodySmall, { color: Colors.textTertiary }]}>
          {value}
        </Text>
      )}
      {onPress && !danger && (
        <Ionicons name="chevron-forward" size={15} color={Colors.textTertiary} style={{ marginLeft: Spacing.sm }} />
      )}
    </Wrapper>
  );
}

function Divider() {
  return <View style={{ height: 1, backgroundColor: Colors.borderLight }} />;
}

export default function SettingsScreen() {
  const { visitors, clearAll } = useVisitors();
  const [showClearModal, setShowClearModal] = useState(false);
  const { statusBarPadding, horizontalPadding, isTablet, contentMaxWidth } = useResponsive();

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {/* Header */}
      <View
        style={{
          paddingTop: statusBarPadding,
          paddingBottom: Spacing.md,
          paddingHorizontal: horizontalPadding,
          backgroundColor: Colors.white,
          borderBottomWidth: 1,
          borderBottomColor: Colors.borderLight,
        }}
      >
        <Text style={[Typography.h2, { color: Colors.textPrimary }]}>
          Settings
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={{
          padding: horizontalPadding,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + 20,
          ...(isTablet ? { alignSelf: 'center', maxWidth: contentMaxWidth, width: '100%' } : {}),
        }}
      >
        {/* App Info */}
        <Text style={[Typography.caption, { color: Colors.textTertiary, textTransform: 'uppercase', marginBottom: Spacing.sm, marginTop: Spacing.lg }]}>
          Informasi
        </Text>
        <View
          style={{
            backgroundColor: Colors.card,
            borderRadius: Radius.lg,
            paddingHorizontal: Spacing.md,
            borderWidth: 1,
            borderColor: Colors.borderLight,
            ...Shadows.card,
          }}
        >
          <SettingsRow icon="server-outline" label="Local Data" value={`${visitors.length} visitor`} />
          <Divider />
          <SettingsRow icon="information-circle-outline" label="Versi Aplikasi" value="1.0.0" />
          <Divider />
          <SettingsRow icon="code-slash-outline" label="Framework" value="Expo SDK 57" />
        </View>

        {/* Preferences */}
        <Text style={[Typography.caption, { color: Colors.textTertiary, textTransform: 'uppercase', marginBottom: Spacing.sm, marginTop: Spacing.xl }]}>
          Preferensi
        </Text>
        <View
          style={{
            backgroundColor: Colors.card,
            borderRadius: Radius.lg,
            paddingHorizontal: Spacing.md,
            borderWidth: 1,
            borderColor: Colors.borderLight,
            ...Shadows.card,
          }}
        >
          <SettingsRow icon="language-outline" label="Bahasa" value="Indonesia" onPress={() => {}} />
          <Divider />
          <SettingsRow icon="notifications-outline" label="Notifikasi" value="Aktif" onPress={() => {}} />
        </View>

        {/* About */}
        <Text style={[Typography.caption, { color: Colors.textTertiary, textTransform: 'uppercase', marginBottom: Spacing.sm, marginTop: Spacing.xl }]}>
          Lainnya
        </Text>
        <View
          style={{
            backgroundColor: Colors.card,
            borderRadius: Radius.lg,
            paddingHorizontal: Spacing.md,
            borderWidth: 1,
            borderColor: Colors.borderLight,
            ...Shadows.card,
          }}
        >
          <SettingsRow icon="shield-checkmark-outline" label="Kebijakan Privasi" onPress={() => {}} />
          <Divider />
          <SettingsRow icon="help-circle-outline" label="Tentang Aplikasi" onPress={() => {}} />
        </View>

        {/* Danger Zone */}
        <Text style={[Typography.caption, { color: Colors.textTertiary, textTransform: 'uppercase', marginBottom: Spacing.sm, marginTop: Spacing.xl }]}>
          Zona Berbahaya
        </Text>
        <View
          style={{
            backgroundColor: Colors.card,
            borderRadius: Radius.lg,
            paddingHorizontal: Spacing.md,
            borderWidth: 1,
            borderColor: Colors.dangerLight,
            ...Shadows.card,
          }}
        >
          <SettingsRow
            icon="trash-outline"
            label="Hapus Semua Data"
            onPress={() => setShowClearModal(true)}
            danger
          />
        </View>
      </ScrollView>

      <ConfirmationModal
        visible={showClearModal}
        title="Hapus Semua Data"
        message="Yakin ingin menghapus semua data visitor? Tindakan ini tidak dapat dibatalkan."
        confirmLabel="Hapus"
        cancelLabel="Batal"
        onConfirm={() => { clearAll(); setShowClearModal(false); }}
        onCancel={() => setShowClearModal(false)}
      />
    </View>
  );
}
