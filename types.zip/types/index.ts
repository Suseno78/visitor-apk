export type VisitorCategory = 'VIP' | 'Reguler' | 'Family' | 'Partner';

export interface Visitor {
  id: string;
  name: string;
  category: VisitorCategory;
  occupation: string;
  address: string;
  phone: string;
  knownFrom: string;
  // Visit info
  visitDay: string;
  visitMonth: string;
  visitYear: string;
  visitTime: string;
  estimatedDuration: string;
  visitNotes: string;
  // Purpose
  problem: string;
  solution: string;
  purposeNotes: string;
  // Status
  status: 'Aktif' | 'Selesai';
  createdAt: number;
  // Legacy compat
  visitDate?: string;
  notes?: string;
}
