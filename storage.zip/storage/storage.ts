import AsyncStorage from '@react-native-async-storage/async-storage';
import { Visitor } from '../types';

const STORAGE_KEY = '@visitors';

export const VisitorStorage = {
  async getAll(): Promise<Visitor[]> {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    if (!data) return [];
    return JSON.parse(data) as Visitor[];
  },

  async getById(id: string): Promise<Visitor | null> {
    const visitors = await this.getAll();
    return visitors.find((v) => v.id === id) || null;
  },

  async save(visitor: Visitor): Promise<void> {
    const visitors = await this.getAll();
    visitors.push(visitor);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(visitors));
  },

  async update(updated: Visitor): Promise<void> {
    const visitors = await this.getAll();
    const index = visitors.findIndex((v) => v.id === updated.id);
    if (index !== -1) {
      visitors[index] = updated;
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(visitors));
    }
  },

  async delete(id: string): Promise<void> {
    const visitors = await this.getAll();
    const filtered = visitors.filter((v) => v.id !== id);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  },

  async clearAll(): Promise<void> {
    await AsyncStorage.removeItem(STORAGE_KEY);
  },
};
