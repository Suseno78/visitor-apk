import { useWindowDimensions, Platform } from 'react-native';

const BREAKPOINT_TABLET = 768;
const BREAKPOINT_DESKTOP = 1024;

export function useResponsive() {
  const { width, height } = useWindowDimensions();
  const isTablet = width >= BREAKPOINT_TABLET;
  const isDesktop = width >= BREAKPOINT_DESKTOP;
  const isWeb = Platform.OS === 'web';
  const isPhone = width < BREAKPOINT_TABLET;

  const contentMaxWidth = isDesktop ? 600 : isTablet ? 560 : width;
  const horizontalPadding = isTablet ? 32 : 20;
  const statusBarPadding = Platform.OS === 'web' ? 16 : 54;

  return {
    width,
    height,
    isPhone,
    isTablet,
    isDesktop,
    isWeb,
    contentMaxWidth,
    horizontalPadding,
    statusBarPadding,
  };
}

// Tab bar constants
export const TAB_BAR_HEIGHT = 74;
export const TAB_BAR_MARGIN = 0; // No longer floating — kept for backward compat
export const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT;
